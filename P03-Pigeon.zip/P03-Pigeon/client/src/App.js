import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link, Navigate } from 'react-router-dom';
import RegistrationPage from './pages/RegistrationPage';
import LoginPage from './pages/LoginPage';
import ChatRoomPage from './pages/ChatRoomPage';  // Import the new ChatRoomPage
import ContactListPage from './pages/ContactListPage';
import Chat from './pages/Chat';
import SettingsPage from './pages/SettingsPage';
import { AuthProvider, useAuth } from './context/AuthContext';
import './App.css';

function App() {
  const { user } = useAuth();

  return (
    <Router>
      <div className="App">
        <nav>
          {!user && <Link to="/login">Login</Link>}
          {user && <Link to="/chatroom">Chat Room</Link>}
          {user && <Link to="/contacts">Contacts</Link>}
          {user && <Link to="/chat">Chat</Link>}
          {user && <Link to="/settings">Settings</Link>}
        </nav>
        <Routes>
          <Route path="/register" element={<RegistrationPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/chatroom" element={user ? <ChatRoomPage /> : <Navigate to="/login" />} />
          <Route path="/contacts" element={user ? <ContactListPage /> : <Navigate to="/login" />} />
          <Route path="/chat" element={<Chat/>} />
          <Route path="/settings" element={user ? <SettingsPage /> : <Navigate to="/login" />} />
          <Route path="/" element={<Navigate to={user ? "/chatroom" : "/register"} />} />
        </Routes>
      </div>
    </Router>
  );
}

export default function AppWithProvider() {
  return (
    <AuthProvider>
      <App />
    </AuthProvider>
  );
}

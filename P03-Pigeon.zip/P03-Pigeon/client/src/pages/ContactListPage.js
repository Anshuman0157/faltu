import React from 'react';

function ContactListPage() {
  return (
    <div>
      <h2>Contact List</h2>
      <ul>
        <li>Contact 1</li>
        <li>Contact 2</li>
      </ul>
    </div>
  );
}

export default ContactListPage;

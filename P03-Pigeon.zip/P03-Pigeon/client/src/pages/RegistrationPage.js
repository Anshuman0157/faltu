import React from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './RegistrationPage.css'; 

const RegistrationPage = () => {
  const navigate = useNavigate();
  const { login } = useAuth(); // Use the login function from AuthContext

  const formik = useFormik({
    initialValues: { email: '', password: '', username: '' },
    validationSchema: Yup.object({
      email: Yup.string().email('Invalid email address').required('Required'),
      password: Yup.string().min(6, 'Password must be at least 6 characters').required('Required'),
      username: Yup.string().min(3, 'Must be at least 3 characters').required('Required'),
    }),
    onSubmit: async (values) => {
      try {
        const response = await fetch('http://127.0.0.1:5000/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include', // Ensure credentials are included
          body: JSON.stringify(values),
        });
        const data = await response.json();
        if (response.ok) {
          alert('User registered successfully!');
          login(data); // Set the user data in the context
          navigate('/chatroom', { replace: true }); // Redirect to ChatRoomPage after registration
        } else {
          alert(data.message || 'Registration failed');
        }
      } catch (error) {
        alert('Registration failed');
      }
    },
  });

  return (
    <div className="registration-container">
      <h2>Register</h2>
      <form onSubmit={formik.handleSubmit} className="registration-form">
        <div className="form-group">
          <input
            type="email"
            name="email"
            placeholder="Email"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.email}
            className={formik.touched.email && formik.errors.email ? 'input-error' : ''}
          />
          {formik.touched.email && formik.errors.email ? (
            <div className="error-message">{formik.errors.email}</div>
          ) : null}
        </div>
        <div className="form-group">
          <input
            type="password"
            name="password"
            placeholder="Password"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.password}
            className={formik.touched.password && formik.errors.password ? 'input-error' : ''}
          />
          {formik.touched.password && formik.errors.password ? (
            <div className="error-message">{formik.errors.password}</div>
          ) : null}
        </div>
        <div className="form-group">
          <input
            type="text"
            name="username"
            placeholder="Username"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.username}
            className={formik.touched.username && formik.errors.username ? 'input-error' : ''}
          />
          {formik.touched.username && formik.errors.username ? (
            <div className="error-message">{formik.errors.username}</div>
          ) : null}
        </div>
        <button type="submit" className="submit-button">Register</button>
      </form>
      <div className="login-link">
        Already have an account? <Link to="/login">Login here</Link>
      </div>
    </div>
  );
};

export default RegistrationPage;

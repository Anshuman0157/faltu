import React from 'react';

function SettingsPage() {
  return (
    <div>
      <h2>Settings</h2>
      <form>
        <input type="text" placeholder="Setting 1" />
        <input type="text" placeholder="Setting 2" />
        <button type="submit">Save</button>
      </form>
    </div>
  );
}

export default SettingsPage;
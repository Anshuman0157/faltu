import React from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import './ChatRoomPage.css'; 

const ChatRoomPage = () => {
  const formikJoin = useFormik({
    initialValues: { joinCode: '' },
    validationSchema: Yup.object({
      joinCode: Yup.string().required('Join code is required'),
    }),
    onSubmit: async (values) => {
      try {
        const response = await fetch(`http://127.0.0.1:5000/room/${values.joinCode}`, {
          method: 'GET',
          headers: { 'Content-Type': 'application/json' },
        });
        const data = await response.json();
        if (response.ok) {
          alert('Joined room successfully!');
          // Redirect to chat page with room ID
        } else {
          console.log('Error:', data.message);
          alert(data.message || 'Failed to join room');
        }
      } catch (error) {
        console.error('Error:', error);
        alert('Failed to join room');
      }
    },
  });

  const formikCreate = useFormik({
    initialValues: { roomName: '' },
    validationSchema: Yup.object({
      roomName: Yup.string().required('Room name is required'),
    }),
    onSubmit: async (values) => {
      try {
        const response = await fetch('http://127.0.0.1:5000/create_room', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ room_name: values.roomName }),
        });
        const data = await response.json();
        if (response.ok) {
          alert(`Room created successfully! Your room ID is: ${data.room_id}`);
          // Redirect to chat page with room ID
        } else {
          console.log('Error:', data.message);
          alert(data.message || 'Failed to create room');
        }
      } catch (error) {
        console.error('Error:', error);
        alert('Failed to create room');
      }
    },
  });

  return (
    <div className="chatroom-container">
      <h2>Join or Create a Chat Room</h2>
      <div className="forms-container">
        <form onSubmit={formikJoin.handleSubmit} className="chatroom-form">
          <h3>Join a Room</h3>
          <div className="form-group">
            <input
              type="text"
              name="joinCode"
              placeholder="Enter Join Code"
              onChange={formikJoin.handleChange}
              onBlur={formikJoin.handleBlur}
              value={formikJoin.values.joinCode}
              className={formikJoin.touched.joinCode && formikJoin.errors.joinCode ? 'input-error' : ''}
            />
            {formikJoin.touched.joinCode && formikJoin.errors.joinCode ? (
              <div className="error-message">{formikJoin.errors.joinCode}</div>
            ) : null}
          </div>
          <button type="submit" className="submit-button">Join Room</button>
        </form>
        <form onSubmit={formikCreate.handleSubmit} className="chatroom-form">
          <h3>Create a Room</h3>
          <div className="form-group">
            <input
              type="text"
              name="roomName"
              placeholder="Enter Room Name"
              onChange={formikCreate.handleChange}
              onBlur={formikCreate.handleBlur}
              value={formikCreate.values.roomName}
              className={formikCreate.touched.roomName && formikCreate.errors.roomName ? 'input-error' : ''}
            />
            {formikCreate.touched.roomName && formikCreate.errors.roomName ? (
              <div className="error-message">{formikCreate.errors.roomName}</div>
            ) : null}
          </div>
          <button type="submit" className="submit-button">Create Room</button>
        </form>
      </div>
    </div>
  );
};

export default ChatRoomPage;
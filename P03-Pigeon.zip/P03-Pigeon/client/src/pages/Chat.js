import React, { useEffect, useRef, useState } from 'react';
import './Chat.css';

const Chat = () => {
  const [sendChannel, setSendChannel] = useState(null);
  const [startButtonDisabled, setStartButtonDisabled] = useState(true);
  const [sendButtonDisabled, setSendButtonDisabled] = useState(true);
  const [closeButtonDisabled, setCloseButtonDisabled] = useState(true);

  const pcRef = useRef(null);
  const signalingRef = useRef(null);
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState('');

  useEffect(() => {
    signalingRef.current = new WebSocket('ws://localhost:8080');
    signalingRef.current.onmessage = e => {
      const data = JSON.parse(e.data);
      switch (data.type) {
        case 'offer':
          handleOffer(data);
          break;
        case 'answer':
          handleAnswer(data);
          break;
        case 'candidate':
          handleCandidate(data);
          break;
        case 'ready':
          if (!pcRef.current) {
            setStartButtonDisabled(false);
          }
          break;
        case 'bye':
          if (pcRef.current) {
            hangup();
          }
          break;
        default:
          console.log('unhandled', e);
          break;
      }
    };

    signalingRef.current.onopen = () => {
      signalingRef.current.send(JSON.stringify({ type: 'ready' }));
    };

    return () => {
      if (signalingRef.current) {
        signalingRef.current.close();
      }
    };
  }, []);

  const createPeerConnection = async () => {
    const newPc = new RTCPeerConnection();
    newPc.onicecandidate = e => {
      const message = {
        type: 'candidate',
        candidate: null,
      };
      if (e.candidate) {
        message.candidate = e.candidate.candidate;
        message.sdpMid = e.candidate.sdpMid;
        message.sdpMLineIndex = e.candidate.sdpMLineIndex;
      }
      signalingRef.current.send(JSON.stringify(message));
    };
    newPc.ondatachannel = receiveChannelCallback;
    pcRef.current = newPc;
    return newPc;
  };

  const startCall = async () => {
    setStartButtonDisabled(true);
    setCloseButtonDisabled(false);

    const newPc = await createPeerConnection();
    pcRef.current = newPc;

    const newSendChannel = newPc.createDataChannel('sendDataChannel');
    setupDataChannel(newSendChannel);

    const offer = await newPc.createOffer();
    await newPc.setLocalDescription(offer);
    signalingRef.current.send(JSON.stringify({ type: 'offer', sdp: offer.sdp }));
  };

  const closeCall = async () => {
    hangup();
    signalingRef.current.send(JSON.stringify({ type: 'bye' }));
  };

  const hangup = async () => {
    if (pcRef.current) {
      pcRef.current.close();
      pcRef.current = null;
    }
    setSendChannel(null);
    setStartButtonDisabled(false);
    setSendButtonDisabled(true);
    setCloseButtonDisabled(true);
    setMessages([]);
  };

  const handleOffer = async offer => {
    if (pcRef.current) {
      console.error('existing peerconnection');
      return;
    }

    const newPc = await createPeerConnection();
    pcRef.current = newPc;

    const newSendChannel = newPc.createDataChannel('sendDataChannel');
    setupDataChannel(newSendChannel);

    await newPc.setRemoteDescription(offer);

    const answer = await newPc.createAnswer();
    await newPc.setLocalDescription(answer);
    signalingRef.current.send(JSON.stringify({ type: 'answer', sdp: answer.sdp }));
  };

  const setupDataChannel = (dataChannel) => {
    dataChannel.onopen = () => {
      console.log('Send channel opened');
      setSendChannel(dataChannel);
      setSendButtonDisabled(false);
    };
    dataChannel.onclose = () => {
      console.log('Send channel closed');
      setSendChannel(null);
      setSendButtonDisabled(true);
    };
    dataChannel.onmessage = onReceiveChannelMessageCallback;
  };

  const receiveChannelCallback = event => {
    console.log('Receive Channel Callback');
    setupDataChannel(event.channel);
  };

  const handleCandidate = async candidate => {
    if (!pcRef.current) {
      console.error('no peerconnection');
      return;
    }
    if (!candidate.candidate) {
      await pcRef.current.addIceCandidate(null);
    } else {
      await pcRef.current.addIceCandidate(candidate);
    }
  };

  const handleAnswer = async answer => {
    if (!pcRef.current) {
      console.error('no peerconnection');
      return;
    }
    await pcRef.current.setRemoteDescription(answer);
  };

  const sendMessage = () => {
    if (inputValue.trim() !== '') {
      const data = inputValue.trim();
      if (sendChannel) {
        sendChannel.send(data);
      }
      setMessages(prevMessages => [...prevMessages, { text: data, sender: 'me' }]);
      setInputValue('');
    }
  };

  const onReceiveChannelMessageCallback = event => {
    console.log('Received Message');
    setMessages(prevMessages => [...prevMessages, { text: event.data, sender: 'other' }]);
  };

  return (
    <div className="chat-container">
      <div className="chat-header">
        <h2>Peer-to-Peer Chat</h2>
        <button id="startButton" onClick={startCall} disabled={startButtonDisabled}>
          Start
        </button>
        <button id="closeButton" onClick={closeCall} disabled={closeButtonDisabled}>
          Close
        </button>
      </div>
      <div className="chat-messages">
        {messages.map((message, index) => (
          <div
            key={index}
            className={`message ${message.sender === 'me' ? 'sent' : 'received'}`}
          >
            {message.text}
          </div>
        ))}
      </div>
      <div className="chat-input">
        <input
          type="text"
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter') {
              sendMessage();
            }
          }}
          placeholder="Type a message..."
          disabled={sendButtonDisabled}
        />
        <button onClick={sendMessage} disabled={sendButtonDisabled}>
          Send
        </button>
      </div>
    </div>
  );
};

export default Chat;

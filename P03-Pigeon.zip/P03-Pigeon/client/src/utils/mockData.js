import { encryptMessage } from './encryptionUtils';

// Mock user data
export const mockUsers = [
  { user_id: 1, username: 'user1', public_key: 'public_key_1' },
  { user_id: 2, username: 'user2', public_key: 'public_key_2' },
];

// Mock messages data
export const mockMessages = [
  { message_id: 1, sender_id: 1, receiver_id: 2, message: encryptMessage('Hello, user2!'), timestamp: new Date(), status: 'sent' },
  { message_id: 2, sender_id: 2, receiver_id: 1, message: encryptMessage('Hi, user1!'), timestamp: new Date(), status: 'received' },
];


export const fetchMessages = async () => {
  return mockMessages;
};

export const sendMessage = async (newMessage) => {
  const message = { ...newMessage, message_id: mockMessages.length + 1, status: 'sent' };
  mockMessages.push(message);
  return message;
};

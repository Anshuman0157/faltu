# P03-Pigeon

# Requirements
* [Nodejs](https://nodejs.org/en)
* [Python](https://www.python.org/)
* [Poetry](https://python-poetry.org/)
* All added to PATH

# Installation

## Signaling Server
1. Navigate to ./signaling_server directory.
2. run `npm install`
3. run `node server.js`

## Server
1. Ensure you are in the ./server directory
2. run `poetry install`
3. run `poetry run flask --app pigeon run --port <PORT>`
_Default port expected by client is 5000 if you do not put --port_

## Client
1. Ensure you are in the ./client directory
2. run `npm install`
3. run `npm start`



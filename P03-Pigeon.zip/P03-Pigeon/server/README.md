# Installation
1. Ensure you are in the ./server directory
2. run `poetry install`
3. run `poetry run flask --app pigeon run`

To test run both instances->  poetry run python instance1.py poetry run python instance2.py

# Register user1 on instance 1
curl -X POST -H "Content-Type: application/json" -d '{"username": "user1", "password": "password1"}' http://127.0.0.1:5002/register

# Register user2 on instance 2
curl -X POST -H "Content-Type: application/json" -d '{"username": "user2", "password": "password2"}' http://127.0.0.1:5001/register


# Log in user1 on instance 1 and store cookies
curl -c cookies_user1.txt -X POST -H "Content-Type: application/json" -d '{"username": "user1", "password": "password1"}' http://127.0.0.1:5002/login

# Log in user2 on instance 2 and store cookies
curl -c cookies_user2.txt -X POST -H "Content-Type: application/json" -d '{"username": "user2", "password": "password2"}' http://127.0.0.1:5001/login

# Add user2 as a contact for user1 on instance 1 using stored cookies
curl -b cookies_user1.txt -X POST -H "Content-Type: application/json" -d '{"contact_id": 2}' http://127.0.0.1:5002/add_contact

# Add user1 as a contact for user2 on instance 2 using stored cookies
curl -b cookies_user2.txt -X POST -H "Content-Type: application/json" -d '{"contact_id": 1}' http://127.0.0.1:5001/add_contact

# Send a message from user1 to user2 on instance 1 using stored cookies
curl -b cookies_user1.txt -X POST -H "Content-Type: application/json" -d '{"receiver_id": 2, "message": "Hello from user1"}' http://127.0.0.1:5002/send_message

# Retrieve messages for user2 from user1 on instance 2 using stored cookies
curl -b cookies_user2.txt -X GET 'http://127.0.0.1:5001/get_messages?contact_id=1'

from flask_sqlalchemy import SQLAlchemy
from . import db
from uuid import uuid4

def get_uuid():
    return uuid4().hex

class Contact(db.Model):
    __tablename__ = "contacts"
    id = db.Column(db.String(32), primary_key=True, unique=True, default=get_uuid)
    username = db.Column(db.String(32), unique=True)
    public_key = db.Column(db.Text, nullable=False)
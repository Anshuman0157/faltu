from flask_sqlalchemy import SQLAlchemy
from . import db
from uuid import uuid4
from pigeon.models.rooms import room_users

def get_uuid():
    return uuid4().hex

class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.String(32), primary_key=True, unique=True, default=get_uuid)
    email = db.Column(db.String(345), unique=True)
    password = db.Column(db.Text, nullable=False)
    username = db.Column(db.String(32), unique=True)
    rooms = db.relationship('Room', secondary=room_users, back_populates='users')
    public_key = db.Column(db.Text, nullable=True)
    private_key = db.Column(db.Text, nullable=True)
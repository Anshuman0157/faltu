from . import db
from uuid import uuid4

def generate_room_id():
    return uuid4().hex

room_users = db.Table('room_users',
    db.Column('user_id', db.String(32), db.ForeignKey('users.id'), primary_key=True),
    db.Column('room_id', db.String(32), db.ForeignKey('rooms.id'), primary_key=True)
)

class Room(db.Model):
    __tablename__ = 'rooms'
    id = db.Column(db.String(32), primary_key=True, unique=True, default=generate_room_id)
    name = db.Column(db.String(255), unique=True, nullable=False)
    users = db.relationship('User', secondary=room_users, back_populates='rooms')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name
        }
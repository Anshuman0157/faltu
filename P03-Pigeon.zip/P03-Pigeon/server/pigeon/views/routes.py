import os
from flask import Blueprint, request, jsonify, session, current_app
from pigeon import bcrypt, cipher_suite
from pigeon.models.users import User
from pigeon.models.rooms import Room
from pigeon.models.contact import Contact
from pigeon.models import db
from flask_socketio import send, emit, join_room, leave_room
import rsa
from base64 import b64encode
from threading import Thread

api = Blueprint('api', __name__)

def field_check(username, email, password):
    if not username or not email or not password:
        return jsonify({"message": "All fields are required."}), 400
    if len(password) < 8:
        return jsonify({"message": "Password must be at least 8 characters long."}), 400
    if '@' not in email or '.' not in email:
        return jsonify({"message": "Invalid email address."}), 400
    return None

def field_check_login(email, password):
    if not email or not password:
        return jsonify({"message": "Email and password are required."}), 400
    if '@' not in email or '.' not in email:
        return jsonify({"message": "Invalid email address."}), 400
    return None

def generate_keys(app, user_id):
    with app.app_context():
        (public_key, private_key) = rsa.newkeys(4096)
        public_key_str = public_key.save_pkcs1().decode('utf-8')
        private_key_str = private_key.save_pkcs1().decode('utf-8')

        user = User.query.get(user_id)
        if user:
            user.public_key = public_key_str
            user.private_key = private_key_str
            db.session.commit()

@api.route('/health', methods = ['GET']) 
def health():
    """Return a status of 'ok' if the server is running and listening to request"""
    return jsonify({"status": "ok"}),200
            
@api.route('/test', methods=['GET'])
def test():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"message": "You are not logged in."}), 401
    
    user = User.query.get(user_id)
    return jsonify({"message": f"Hello, {user.username}!"})

@api.route('/register', methods=['POST'])
def register():
    email = request.json["email"]
    password = request.json["password"]
    username = request.json.get("username")
    
    field_check_response = field_check(username, email, password)
    if field_check_response:
        return field_check_response
    
    if User.query.filter_by(email=email).first():
        return jsonify({"message": "User already exists."}), 409
    
    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    
    user = User(email=email, password=hashed_password, username=username)
    db.session.add(user)
    db.session.commit()
    Thread(target=generate_keys, args=(current_app._get_current_object(), user.id)).start()
    
    session["user_id"] = user.id
    
    return jsonify({
        "user_id" : user.id,
        "user_email" : user.email,
        "public_key": user.public_key
    }), 200

@api.route('/login', methods=['POST'])
def login():
    email = request.json["email"]
    password = request.json["password"]
    
    field_check_response = field_check_login(email, password)
    if field_check_response:
        return field_check_response
    
    user = User.query.filter_by(email=email).first()
    
    if not user or not bcrypt.check_password_hash(user.password, password):
        return jsonify({"message": "Invalid credentials."}), 401
    
    session["user_id"] = user.id
    
    return jsonify({
        "user_id" : user.id,
        "user_email" : user.email
    }), 200
    
    
@api.route("/logout", methods=["POST"])
def logout_user():
    session.pop("user_id")
    return "200"

@api.route('/create_room', methods=['POST'])
def create_room():

    room_name = request.json.get('room_name')
    if not room_name:
        return jsonify({"message": "Room name is required."}), 400
    
    if Room.query.filter_by(name=room_name).first():
        return jsonify({"message": "Room already exists."}), 409

    new_room = Room(name=room_name)
    db.session.add(new_room)
    db.session.commit()

    return jsonify({
        "room_id": new_room.id,
        "room_name": new_room.name,
        "message": "Room created successfully"
    }), 200
    
@api.route('/room/<room_id>', methods=['GET'])
def get_room(room_id):
    room = Room.query.get(room_id)
    if room:
        return jsonify(room.to_dict()), 200
    return jsonify({"message": "Room not found"}), 404

@api.route('/get_keys', methods=['GET'])
def get_keys():
    user_id = session.get('user_id')
    # if not user_id:
    #     return jsonify({"message": "Authentication required."}), 401
    
    # user = User.query.get(user_id)
    # return jsonify({
    #     "user_id" : user.id,
    #     "public_key" : user.public_key,
    #     "private_key" : user.private_key
    # }), 200

    return jsonify({
        "public_key": 'pub',
        "private_key": 'priv'
    }), 200

@api.route('/add_contact', methods=['POST'])
def add_contact():
    # user_id = session.get('user_id')
    # if not user_id:
    #     return jsonify({"message": "Authentication required."}), 401

    # add a contact, requires their username and public key
    username = request.json.get('username')
    public_key = request.json.get('public_key')

    if not username or not public_key:
        return jsonify({"message": "Username and public key are required."}), 400

    existing_contact = Contact.query.filter_by(username=username).first()
    if existing_contact:
        return jsonify({"message": "Contact already exists."}), 409

    new_contact = Contact(username=username, public_key=public_key)
    db.session.add(new_contact)
    db.session.commit()

    return jsonify({"message": "Contact added successfully."}), 201

@api.route('/get_contacts', methods=['GET'])
def get_contacts():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"message": "Authentication required."}), 401

    contacts = Contact.query.all()
    contacts_list = []
    for contact in contacts:
        contacts_list.append(contact.to_dict())
    
    return jsonify(contacts_list), 200

@api.route('/get_public_key/<username>', methods=['GET'])
def get_public_key(username):
    # user_id = session.get('user_id')
    # if not user_id:
    #     return jsonify({"message": "Authentication required."}), 401

    contact = Contact.query.filter_by(username=username).first()
    if not contact:
        return jsonify({"message": "Contact not found."}), 404

    return jsonify({"public_key": contact.public_key}), 200

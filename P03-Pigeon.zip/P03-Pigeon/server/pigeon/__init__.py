from datetime import timedelta
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_cors import CORS
from flask_session import Session
from flask_socketio import SocketIO
from cryptography.fernet import Fernet
import redis

bcrypt = Bcrypt()
socketio = SocketIO()

# Shared encryption key
shared_encryption_key = 'S1b2MZ8XgKaZLHD883dBZyAOfzHsdLJpUDnpxSmtBCk='
cipher_suite = Fernet(shared_encryption_key)

def create_app(test_config=None):
    app = Flask(__name__)
    
    if test_config:
        # Load the test configuration if passed in
        app.config.update(test_config)
    else:
        app.config['SECRET_KEY'] = 'your_secret_key'
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite'
        app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        
        # set up redis for sessions
        app.config['SESSION_TYPE'] = 'redis'
        app.config['SESSION_PERMANENT'] = False
        app.config['SESSION_USE_SIGNER'] = True
        app.config['SESSION_KEY_PREFIX'] = 'pigeon'
        app.config['SESSION_REDIS'] = redis.from_url('redis://localhost:6379')
        app.config['SESSION_COOKIE_NAME'] = 'session'  # Choose a unique name for your session cookie.
        app.config['SESSION_COOKIE_DOMAIN'] = None  # More restricted and secure; only send the cookie to the exact domain it was set from.
        app.config['SESSION_COOKIE_PATH'] = '/'
        app.config['SESSION_COOKIE_SECURE'] = False  # Set to True if serving over HTTPS.
        app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'  # Recommended to mitigate CSRF attacks.
        app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=31)  # Default lifetime of the session.
        app.config['SESSION_REFRESH_EACH_REQUEST'] = True  # Refresh the session cookie on each request to keep the session from expiring.

        
    CORS(app, supports_credentials=True, origins="*")

    
    sess = Session()
    sess.init_app(app) 
    from pigeon.models import db
    from pigeon.models.users import User
    from pigeon.models.rooms import Room
    db.init_app(app)
    bcrypt.init_app(app)

    #socketio.init_app(app, cors_allowed_origins="*")
    

    with app.app_context():
        db.create_all()
        db.session.commit()
        
    from pigeon.views.routes import api
    app.register_blueprint(api)

    return app
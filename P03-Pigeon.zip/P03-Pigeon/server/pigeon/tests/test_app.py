import pytest
from pigeon import create_app, bcrypt
from pigeon.models import db
from pigeon.models.users import User
from flask_bcrypt import Bcrypt
from flask import session

@pytest.fixture
def client():
    app = create_app({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:',
        'SECRET_KEY': 'test_secret_key',
        'SESSION_TYPE': 'filesystem'
    })

    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            yield client

def test_register(client):
    """Test user registration."""
    response = client.post('/register', json={
        'email': 'test@example.com',
        'password': 'test123',
        'username': 'testuser'
    })
    assert response.status_code == 200
    assert b'User already exists' not in response.data

def test_login(client):
    """Test user login."""
    # Setup a user
    password = 'test123'
    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')  # Use the same bcrypt instance
    with client.application.app_context():  # Ensure an application context is active
        user = User(email='user@example.com', password=hashed_password, username='testuser')
        db.session.add(user)
        db.session.commit()

    # Test login with correct credentials
    response = client.post('/login', json={
        'email': 'user@example.com',
        'password': 'test123'  # Correct password
    })
    assert response.status_code == 200
    json_data = response.get_json()
    
    with client.application.app_context():
        user_from_db = User.query.filter_by(email='user@example.com').first()
        assert json_data['user_id'] == str(user_from_db.id)

    # Test logout
    response = client.post('/logout')
    assert response.status_code == 200

    # Test login with incorrect credentials
    response = client.post('/login', json={
        'email': 'user@example.com',
        'password': '123456'  # Incorrect password
    })
    assert response.status_code == 401  # Expecting Unauthorized status
    
def test_register_existing_user(client):
    """Test registering an existing user."""
    # Setup a user
    password = 'test123'
    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')  # Use the same bcrypt instance
    with client.application.app_context():  # Ensure an application context is active
        user = User(email='user@example.com', password=hashed_password, username='testuser')
        db.session.add(user)
        db.session.commit()
    
    # Try to register the same user
    response = client.post('/register', json={
        'email': 'user@example.com',
        'password': 'test123',
        'username': 'testuser'
    })
    
    assert response.status_code == 409  # Expecting Conflict status
    assert b'User already exists' in response.data
    
def test_login_invalid_email_format(client):
    """Test login with invalid email format."""
    response = client.post('/login', json={
        'email': 'invalid-email',
        'password': 'password123'
    })
    assert response.status_code == 400

def test_login_empty_fields(client):
    """Test login with empty fields."""
    response = client.post('/login', json={
        'email': '',
        'password': ''
    })
    assert response.status_code == 400

def test_session_management_on_login(client):
    """Ensure session is set after logging in."""
    # Assuming user creation and login endpoints are working correctly.
    client.post('/register', json={
        'email': 'session@example.com',
        'password': 'password123',
        'username': 'sessionuser'
    })
    response = client.post('/login', json={
        'email': 'session@example.com',
        'password': 'password123'
    })
    # This should set the session
    assert 'user_id' in session
    assert response.status_code == 200

def test_logout_session_clearance(client):
    """Ensure session is cleared after logging out."""
    password = 'test123'
    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')  # Use the same bcrypt instance
    with client.application.app_context():  # Ensure an application context is active
        user = User(email='user@example.com', password=hashed_password, username='testuser')
        db.session.add(user)
        db.session.commit()

    # Test login with correct credentials
    response = client.post('/login', json={
        'email': 'user@example.com',
        'password': 'test123'  # Correct password
    })
    assert response.status_code == 200
    
    with client.session_transaction() as sess:
        assert 'user_id' in sess  # Ensure the session is set

    logout_response = client.post('/logout')
    assert logout_response.status_code == 200

    with client.session_transaction() as sess:
        assert 'user_id' not in sess  # Ensure the session is cleared

def test_create_room_with_empty_name(client):
    """Test creating a room with no name provided."""
    response = client.post('/create_room', json={'room_name': ''})
    assert response.status_code == 400

def test_room_details_retrieval(client):
    """Test retrieval of room details after creation."""
    # Assuming a room has been created
    create_response = client.post('/create_room', json={'room_name': 'New Room'})
    room_id = create_response.get_json()['room_id']
    get_response = client.get(f'/room/{room_id}')
    assert get_response.status_code == 200

def test_room_creation(client):
    """Test room creation."""
    response = client.post('/create_room', json={'room_name': 'New Room'})
    assert response.status_code == 200

def test_room_creation_with_existing_name(client):
    """Test creating a room with an existing name."""
    # Assuming a room has been created
    create_response = client.post('/create_room', json={'room_name': 'New Room'})
    assert create_response.status_code == 200
    response = client.post('/create_room', json={'room_name': 'New Room'})
    assert response.status_code == 409
#!/bin/bash

docker build ./client/. -t client

docker build ./server/. -t server

docker build ./signalling_server/. -t sig

docker run -d -p 3000:3000 client

docker run -d -p 5000:5000 server

docker run -d -p 8080:8080 sig
// signalingServer.js
const WebSocket = require('ws');

const PORT = 8080;
const server = new WebSocket.Server({ port: PORT });

server.on('connection', ws => {
  ws.on('message', message => {
    server.clients.forEach(client => {
      if (client !== ws && client.readyState === WebSocket.OPEN) {
        client.send(message.toString());
      }
    });
  });
});

console.log(`Signaling server running on ws://localhost:${PORT}`)

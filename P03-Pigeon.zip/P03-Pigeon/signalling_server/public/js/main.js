var isChannelReady = false;
var isInitiator = false;
var isStarted = false;
var pc;
var clientName = "user" + Math.floor(Math.random() * 1000 + 1);
var remoteclient;

document.getElementById("yourname").innerHTML = "You: " + clientName;

var pcConfig = turnConfig;
var room = "test";
var socket = io.connect();

var sendmessagebutton = document.getElementById("sendmessagebutton");
var messageInput = document.getElementById("messageInput");
var messagesDiv = document.getElementById("messages");

socket.on("created", function (room) {
  console.log("Created room", room);
  isInitiator = true;
});

socket.on("full", function (room) {
  console.log("Room", room, "is full");
});

socket.on("join", function (room, client) {
  console.log("Peer", client, "joined room", room);
  sendmessagebutton.disabled = false;
  isChannelReady = true;
  remoteclient = client;
  document.getElementById("remotename").innerHTML = client;
  socket.emit("creatorname", room, clientName);
});

socket.on("mynameis", function (client) {
  console.log("Creator's name is", client);
  remoteclient = client;
  document.getElementById("remotename").innerHTML = client;
});

socket.on("joined", function (room) {
  console.log("Joined room", room);
  isChannelReady = true;
  sendmessagebutton.disabled = false;
});

socket.on("message", function (message, room) {
  console.log("Received message:", message, "in room", room);
  handleMessage(message);
});

function handleMessage(message) {
  if (message === "gotuser") {
    maybeStart();
  } else if (message.type === "offer") {
    if (!isInitiator && !isStarted) {
      maybeStart();
    }
    pc.setRemoteDescription(new RTCSessionDescription(message));
    doAnswer();
  } else if (message.type === "answer" && isStarted) {
    pc.setRemoteDescription(new RTCSessionDescription(message));
  } else if (message.type === "candidate" && isStarted) {
    var candidate = new RTCIceCandidate({
      sdpMLineIndex: message.label,
      candidate: message.candidate,
    });
    pc.addIceCandidate(candidate);
  } else if (message === "bye" && isStarted) {
    handleRemoteHangup();
  } else if (typeof message === "string") {
    displayMessage(message, false);
  }
}

function sendMessage(message, room) {
  console.log("Sending message:", message, "to room", room);
  socket.emit("message", message, room);
}

function maybeStart() {
  console.log("maybeStart:", isStarted, isChannelReady);
  if (!isStarted && isChannelReady) {
    console.log("Creating peer connection");
    createPeerConnection();
    isStarted = true;
    console.log("isInitiator", isInitiator);
    if (isInitiator) {
      doCall();
    }
  }
}

window.onbeforeunload = function () {
  sendMessage("bye", room);
};

function createPeerConnection() {
  try {
    pc = new RTCPeerConnection(pcConfig);
    pc.onicecandidate = handleIceCandidate;
    console.log("Created RTCPeerConnection");
  } catch (e) {
    console.log("Failed to create PeerConnection:", e.message);
    alert("Cannot create RTCPeerConnection object.");
  }
}

function handleIceCandidate(event) {
  console.log("IceCandidate event:", event);
  if (event.candidate) {
    sendMessage(
      {
        type: "candidate",
        label: event.candidate.sdpMLineIndex,
        id: event.candidate.sdpMid,
        candidate: event.candidate.candidate,
      },
      room
    );
  } else {
    console.log("End of candidates");
  }
}

function handleCreateOfferError(event) {
  console.log('createOffer() error: ', event);
}

function doCall() {
  console.log("Sending offer to peer");
  pc.createOffer(setLocalAndSendMessage, handleCreateOfferError);
}

function doAnswer() {
  console.log("Sending answer to peer");
  pc.createAnswer().then(setLocalAndSendMessage, onCreateSessionDescriptionError);
}

function setLocalAndSendMessage(sessionDescription) {
  pc.setLocalDescription(sessionDescription);
  console.log("Sending local description:", sessionDescription);
  sendMessage(sessionDescription, room);
}

function onCreateSessionDescriptionError(error) {
  console.log("Failed to create session description:", error.toString());
}

function hangup() {
  console.log("Hanging up");
  stop();
}

function handleRemoteHangup() {
  console.log("Session terminated");
  stop();
  isInitiator = false;
}

function stop() {
  isStarted = false;
  pc.close();
  pc = null;
}

var connectbutton = document.getElementById("connectbutton");
if (connectbutton) {
  connectbutton.addEventListener("click", function () {
    if (connectbutton.innerHTML !== "Connected") {
      socket.emit("create or join", room, clientName);
      if (isInitiator) {
        maybeStart();
      }
    }
    connectbutton.innerHTML = "Connected";
  });
}

function displayMessage(message, isLocal) {
  var messageElement = document.createElement("div");
  messageElement.classList.add("message");
  if (isLocal) {
    messageElement.classList.add("local");
  }
  messageElement.innerText = message;
  messagesDiv.appendChild(messageElement);
}

sendmessagebutton.addEventListener("click", function () {
  var message = messageInput.value;
  sendMessage(message, room);
  displayMessage(message, true);
  messageInput.value = "";
});